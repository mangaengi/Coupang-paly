import React, {useEffect } from 'react'
import Banner from '../components/Banner'
import { MovieAction } from '../redux/actions/MovieAction';
import { useDispatch, useSelector } from 'react-redux';

const Home = () => {
  const dispatch = useDispatch();
  const {popularMovise } = useSelector ((state) => state.movie)
  console.log("home" , popularMovise)

  useEffect(()=> {
    dispatch(MovieAction.getMovies())
  },[])


  return (
    <div>
        <Banner movie={popularMovise.results[0]}/>
        <div className='contants'>
            <h2>what's popular</h2>
            <h2>Top Rated Movies</h2>
            <h2>Upcomming Movise</h2>
        </div>
    </div>
    
  )
}

export default Home