import React from 'react'

const Movies = () => {
  return (
    <div>
      <h2>Movies</h2>
    </div>
  )
}

export default Movies
